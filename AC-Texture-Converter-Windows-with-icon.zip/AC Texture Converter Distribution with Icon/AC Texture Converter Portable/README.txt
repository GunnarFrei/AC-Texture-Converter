﻿AC Texture Converter â€” Portable build

Run "AC Texture Converter.exe" to open the app. Drop DDS or supported image files onto the window, or use Add files.

This folder must stay together: the executable starts ACTextureConverter.ps1, and texconv.exe performs the texture conversion. Windows PowerShell 5.1 and the Microsoft Visual C++ 2015â€“2022 x64 runtime are required. Texconv is from Microsoft's DirectXTex project and is licensed under MIT.

The portable copy does not install an Explorer menu entry. To use the existing Explorer integration, run the project's Install-ACTextureConverter.bat. That installation remains separate from this portable folder.
