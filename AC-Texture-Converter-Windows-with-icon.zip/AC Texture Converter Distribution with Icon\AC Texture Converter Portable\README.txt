﻿AC Texture Converter v0.9 - Portable build

Run "AC Texture Converter.exe" to open the app. Drop DDS or supported image files onto the window, or use Add files.

Keep this folder together: the executable starts ACTextureConverter.ps1, and texconv.exe performs the texture conversion. Windows PowerShell 5.1 and the Microsoft Visual C++ 2015-2022 x64 runtime are required.

AC Texture Converter is licensed under MIT; see LICENSE. Texconv is also MIT-licensed; see ThirdPartyNotices.txt.

The portable copy does not install an Explorer menu entry. To use the existing Explorer integration, run the project's Install-ACTextureConverter.bat. That installation remains separate from this portable folder.
